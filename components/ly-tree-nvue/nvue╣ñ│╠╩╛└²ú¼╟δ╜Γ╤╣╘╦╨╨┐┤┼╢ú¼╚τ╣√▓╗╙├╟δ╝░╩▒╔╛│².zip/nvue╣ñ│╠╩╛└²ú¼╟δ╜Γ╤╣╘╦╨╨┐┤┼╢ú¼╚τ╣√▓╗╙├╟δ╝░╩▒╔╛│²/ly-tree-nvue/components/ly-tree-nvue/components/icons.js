export default {
	'icon-unchecked': "\ue852",
	'icon-radio-disabled': "\ue853",
	'icon-radio-unchecked': "\ue854",
	'icon-checked': "\ue855",
	'icon-check-disabled': "\ue856",
	'icon-indeterminate': "\ue85a",
	'icon-radio-checked': "\ue86b"
}